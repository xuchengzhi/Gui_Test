package com.test;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
 
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Log extends JFrame  {
	public static void main(String[] args) {
	        Log log = new Log();
	    }
	    private JButton qr_no_icon;//������ico
	    private JButton qr_icon; //����ico
	    private JTextField qr_name; //����
	    private JTextField qr_size; //��С
	    private JTextField qr_bg_c; //����ɫ
	    private JTextField qr_front_c;//ǰ��ɫ
//	    private JPasswordField tfPwd;
	    private JCheckBox qr_is_transparent;//�Ƿ�͸��
//	    private JTextField tfUser;
		private JComboBox adminType;
	 

		public Log() {
	        super("����");
	        super.setSize(380, 292);
	        super.setVisible(true);
	        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        centered(this);
	        qr_no_icon = new JButton("û��icon����");
	        qr_icon =new JButton("��icon����");
	        qr_no_icon.setBounds(new Rectangle(93, 220, 180, 30));//�����ֱ�������x��y��������
	        qr_icon.setBounds(new Rectangle(93, 180, 180, 30));//�����ֱ�������x��y��������
	        this.setLayout(null);//���ò��ֹ�����Ϊ��
	        this.add(qr_no_icon);
	        this.add(qr_icon);
	        qr_name = new JTextField();
	        qr_name.setBounds(new Rectangle(73, 15, 220, 25));
	        this.add(qr_name);
	        qr_size = new JTextField();
	        qr_size.setBounds(new Rectangle(73, 45, 220, 25));
	        this.add(qr_size);
	        qr_bg_c = new JTextField();
	        qr_bg_c.setBounds(new Rectangle(73, 75, 220, 25));
	        this.add(qr_bg_c);
	        qr_front_c = new JTextField();
	        qr_front_c.setBounds(new Rectangle(73, 105, 220, 25));
	        this.add(qr_front_c);
//	        tfPwd = new JPasswordField();
//	        tfPwd.setBounds(new Rectangle(73, 150, 220, 25));
//	        this.add(tfPwd);
	        qr_is_transparent = new JCheckBox("�Ƿ�͸��");
	        qr_is_transparent.setBounds(new Rectangle(118, 145, 110, 25));
	        this.add(qr_is_transparent);
//	        adminType = new JComboBox<Object>(new String[] { "��ְͨԱ", "����Ա", "�߼�����Ա" });
//	        adminType.setBounds(new Rectangle(183, 185, 100, 25));
//	        this.add(adminType);
	 
	    }
	//���־��з���
	    public void centered(Container container) {
	        Toolkit toolkit = Toolkit.getDefaultToolkit();
	        Dimension screenSize = toolkit.getScreenSize();
	        int w = container.getWidth();
	        int h = container.getHeight();
	        container.setBounds((screenSize.width - w) / 2,
	                (screenSize.height - h) / 2, w, h);
	    }

}
